#pragma once
#pragma once
#include "../../Utility/Headers/ShaderManager.h"
#include "../../Source/Common.h"

#define PATCH_SIZE  64

class TerrainShader {
private:
	ShaderManager shaderProgramObject;
	std::vector<GLfloat> vertices;
	GLuint mesh_width;
	GLuint mesh_height;
	GLuint vao_terrain;
	GLuint vbo_terrain_position;
	GLfloat gridSpace = 0.5f;
	GLfloat hightStep = 49.89f;
	GLfloat scaleTerrain = 0.5f;
	GLuint height_texture;

public:
	int initializeTerrainShaderProgram();
	void useTerrainShaderProgram();
	void displayTerrainShader(TextureManager* terrainTextures);
	void unUseTerrainShaderProgram();
	void deleteShaderProgramObject();
};